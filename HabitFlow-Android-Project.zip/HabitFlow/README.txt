HABITFLOW ANDROID APP SOURCE

This is an offline-first Android app project. It stores habits and checkmarks locally on the phone using WebView localStorage. It does not require an account or network access.

BUILD AN APK (requires a computer with Android Studio):
1. Install Android Studio from https://developer.android.com/studio
2. Open Android Studio > Open, then select the HabitFlow folder.
3. Allow Gradle sync and install the Android SDK platform requested by the project (API 35).
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. When the build finishes, choose Locate. The debug APK is normally at app/build/outputs/apk/debug/app-debug.apk.
6. Transfer that APK to your Android phone, open it, and allow installation from that source if Android asks.

APP FEATURES
- Seven starter habits
- Add/edit/delete habits and category filters
- Daily completion percentage
- Previous-day review and future-day navigation
- Perfect-day streak and 7-day overview
- Offline local storage on the device

PACKAGE: com.habitflow.app
MINIMUM ANDROID: Android 6.0 (API 23)
NOTE: This archive is the complete Android Studio source project, not a compiled APK. This environment does not have the Android SDK/Gradle build toolchain installed, so it cannot compile and verify an APK here.
